# Seth Ayers
# CSIT 200 - 01
# 10/20/2016
# lab6
# tsa_simulator.py


import random          # Imports random functions
import passenger       # Imports the passenger class
import queues          # Imports the queue class

def main():
    """The main function creates conditions that are decided by the user"""
    simulation_time = int(input('Please enter the simulation time frame greater than 0:'))  # User inputted timeframe for simulation
    while simulation_time <= 0:                                                             # Validation loop, checks if input is correct
        simulation_time = int(input('Incorrect time frame, please enter a time greater than 0: '))  # Requests input if validation fails


    passenger_prob = float(input('Enter the probability of passenger entering the line (0 to 1): '))  # User inputted passenger probability
    while passenger_prob > 1 or passenger_prob < 0:                                                   # Validation loop, checks if input is correct
        passenger_prob = float(input('Enter a correct probability of passengers, (0 to 1): '))        # Requests input if validation fails


    tsa_precheck = input('Is there a TSA precheck line? [Y/N]')             # Asks user if TSA check is active
    while tsa_precheck != 'Y' and tsa_precheck != 'N':                      # Validation loop, checks if input is correct
        tsa_precheck = input('Is there a TSA precheck line? [Y/N]')         # Requests input if validation fails

    if tsa_precheck == "Y":        # Checks if TSA is active
        tsa_prob = float(input('Enter the probability that a passenger has a TSA pre-check:'))      # User inputted TSA probability
        while tsa_prob > 1 or tsa_prob < 0:                                                         # Validation loop, checks if input is correct
            tsa_prob = float(input('Enter a correct probability of TSA passenger, (0 through 1)'))  # Requests input if validation fails
    else:
        tsa_prob = False    # If TSA is not active, assigns value a boolean to prevent errors passing the variable

    id_check_time = int(input('Enter the ID check time (in seconds).  Must be greater than 0:'))  # User inputted ID check time
    while id_check_time <= 0:                                                             # Validation loop, checks if input if correct
        id_check_time = int(input('Enter a correct ID check time (greater than 0):'))     # Requests input if validation fails


    scan_check_time = int(input('Enter the total scan time (in seconds, greater than 0):'))  # User inputted scan check time
    while scan_check_time <= 0:                                                           # Validation loop, checks if input is correct
        scan_check_time = int(input('Enter a correct scan time greater than 0:'))         # Requests input if validation fails

    if tsa_precheck == "Y":        # Checks if TSA is active
        tsa_pass_scan = int(input('Enter the total scan time for the TSA line (in seconds, greater than 0):'))  # User inputted TSA scan time
        while tsa_pass_scan <= 0:                                                         # Validation loop, checks if input is correct
            tsa_pass_scan = int(input('Enter a correct TSA scan time greater than 0:'))   # Requests input if validation fail
    else:
        tsa_pass_scan = False   # If TSA is not active, assigns value a boolean to prevent error passing the variable

    run_simulation(simulation_time, passenger_prob, tsa_precheck, tsa_prob,
            id_check_time, scan_check_time,tsa_pass_scan) # Calls the run_simulation function with all the inputted conditions arguments



def run_simulation(sim_time, pass_prob, tsa_check, tsa_prob, id_check_time, scan_check_time, tsa_scan_time):
    """Run simulation takes the arguments of the main and assigns passengers to id lanes, scanner lanes, and the
    TSA section.  Wait times are recorded for the total time in all lanes and averaged for times for each individual lane.
    """
    tsa_id_line = queues.LinkedQueue()          # Creates instance of the TSA ID line
    reg_id_line = queues.LinkedQueue()          # Creates instance of the regular ID line
    tsa_scan_line = queues.ArrayQueue()         # Creates instance of the TSA scan line
    line1 = queues.ArrayQueue()                 # Creates instance of regular lane 1
    line2 = queues.ArrayQueue()                 # Creates instance of regular lane 2
    line3 = queues.ArrayQueue()                 # Creates instance of regular lane 3
    line4 = queues.ArrayQueue()                 # Creates instance of regular lane 4

    tsa_id_line_count = 0                       # Counts in seconds the elapsed time in the TSA ID line
    reg_id_line_count = 0                       # Counts in seconds the elapsed time in the regular ID line

    tsa_scan_line_count = 0                     # Counts in seconds the elapsed time in the TSA scan line
    line1_time_count = 0                        # Counts in seconds the elapsed time in lane 1 scan
    line2_time_count = 0                        # Counts in seconds the elapsed time in lane 2 scan
    line3_time_count = 0                        # Counts in seconds the elapsed time in lane 3 scan
    line4_time_count = 0                        # Counts in seconds the elapsed time in lane 4 scan

    line1_count = 0                             # Counter for the number of passengers in lane 1
    line2_count = 0                             # Counter for the number of passengers in lane 2
    line3_count = 0                             # Counter for the number of passengers in lane 3
    line4_count = 0                             # Counter for the number of passengers in lane 4
    tsa_count = 0                               # Counter for the number of passengers in TSA scan line

    tsa_pass_total = 0                          # Accumulator for the total sum of passengers that clear the TSA scan line
    pass_total_line1 = 0                        # Accumulator for the total sum of passengers that clear the lane 1 scan
    pass_total_line2 = 0                        # Accumulator for the total sum of passengers that clear the lane 2 scan
    pass_total_line3 = 0                        # Accumulator for the total sum of passengers that clear the lane 3 scan
    pass_total_line4 = 0                        # Accumulator for the total sum of passengers that clear the lane 4 scan
    pass_total = 0

    tsa_wait_times = 0                          # Accumulator for the wait times for each passenger in the TSA scan lane
    line1_wait_times = 0                        # Accumulator for the wait times for each passenger in the lane1 scan lane
    line2_wait_times = 0                        # Accumulator for the wait times for each passenger in the lane2 scan lane
    line3_wait_times = 0                        # Accumulator for the wait times for each passenger in the lane3 scan lane
    line4_wait_times = 0                        # Accumulator for the wait times for each passenger in the lane4 scan lane

    total_time_count = 0                        # Accumulator for the total elapsed time of the simulation


    for seconds in range(sim_time * 60):        # Loop to iterate through the inputted simulation time * 60 for minutes to seconds
        prob_check = random.uniform(0,1)        # Create variable for a random value between 0-1
        p = passenger.Passenger()               # Creates an instance of a regular passenger.  Also accounts for total wait time.
        tsa_wait = passenger.Passenger()        # Creates an instance of passenger to account for the TSA lane wait time.
        line1_wait = passenger.Passenger()      # Creates an instance of passenger to account for the wait time of lane 1.
        line2_wait = passenger.Passenger()      # Creates an instance of passenger to account for the wait time of lane 2.
        line3_wait = passenger.Passenger()      # Creates an instance of passenger to account for the wait time of lane 3.
        line4_wait = passenger.Passenger()      # Creates an instance of passenger to account for the wait time of lane 4.

        if pass_prob > prob_check:                                  # Checks if passenger passes probability check
            p.pass_enter_time(total_time_count)                     # Gets start time as a passenger enters a lane
            if tsa_check == 'Y':                                    # Checks if TSA check is active
                tsa_prob_check = random.uniform(0,1)                # Create variable for a random value between 0-1
                if tsa_prob > tsa_prob_check:                       # Checks if inputted TSA probability passes the check
                    tsa_id_line.enqueue(p)                          # If check passes, enqueue passenger to TSA ID check lane
                else:
                    reg_id_line.enqueue(p)                          # Else, enqueue the passenger to the regular ID lane
                if tsa_id_line_count >= id_check_time:              # Checks if the tsa time counter is greater or equal to inputted ID lane time
                        if tsa_id_line.is_empty() != True:          # Check to see if the ID lane is empty
                            if tsa_count < 10:                                  # Checks to see if the tsa scan line has room.
                                tsa_id_pass = tsa_id_line.dequeue()             # Creates variable for the dequeued passenger
                                tsa_id_line_count = 0                           # Resets the TSA scan lane time counter to 0
                                tsa_scan_line.enqueue(tsa_id_pass)              # Enqueues the passenger to the TSA scan lane
                                tsa_wait.pass_enter_time(total_time_count)      # Enters the current time to the passenger class
                                tsa_count += 1                                  # Adds 1 to the passenger count in the TSA scan lane

                if tsa_scan_line_count >= tsa_scan_time:                  # Checks if the tsa scan lane time is greater or equal to the inputed scan time
                    if tsa_scan_line.is_empty() != True:                  # Checks if the TSA scan lane is empty
                        tsa_scan_line.dequeue()                           # If not empty, dequeue passenger form the TSA scan lane
                        tsa_wait.pass_exit_time(total_time_count)         # Sends the exit time to passenger class for TSA lane wait time
                        tsa_wait_times += tsa_wait.return_wait_time()     # Gets the wait time of passenger in the TSA lane, adds to accumulator
                        tsa_pass_total += 1                               # Adds to TSA passenger total cleared accumulator
                        tsa_scan_line_count = 0                           # Resets TSA lane time counter
                        pass_total += 1                                   # Adds a passenger to the total passenger accumulator
                        tsa_count -= 1                                    # Reduces the length of passengers in the TSA lane by 1
            else:
                reg_id_line.enqueue(p)              # Enqueues passenger to regular ID is TSA probability fails.


        if  reg_id_line_count >= id_check_time:              # Checks if the regular id time is greater/equal to the user inputed time
            if reg_id_line.is_empty() != True:               # Checks if the regular ID line is empty
                if line1_count < 10 and line2_count < 10 \
                and line3_count < 10 and line4_count < 10:   # Checks if all scan lanes are full
                    reg_pass = reg_id_line.dequeue()         # Dequeues a passenger from the regular id lane, assigns variable
                    reg_id_line_count = 0                    # Resets the regular ID line time to 0

                    if line1_count <= line2_count and \
                        line1_count <= line3_count \
                        and line1_count <= line4_count:                 # Checks if scan lane 1 is the shortest
                        line1.enqueue(reg_pass)                         # Enqueues scan lane1 with passenger
                        line1_count += 1                                # Scan lane1 passenger count increased
                        line1_wait.pass_enter_time(total_time_count)    # Sends the enter time to the passenger class
                    elif line2_count <= line3_count \
                        and line2_count <= line4_count:                 # Checks if scan lane2 is the shortest
                        line2.enqueue(reg_pass)                         # Enqueues scan lane2 with passenger
                        line2_count += 1                                # Scan lane2 passenger count increased
                        line2_wait.pass_enter_time(total_time_count)    # Sends the enter time to the passenger class
                    elif line3_count <= line4_count:                    # Checks if scan lane3 is the shortest
                        line3.enqueue(reg_pass)                         # Enqueues scan lane3 with passenger
                        line3_count += 1                                # Scan lane3 passenger count increased
                        line3_wait.pass_enter_time(total_time_count)    # Sends the enter time to the passenger class
                    elif line4_count < 10:                              # Checks if lane 4 if less than 10
                        line4.enqueue(reg_pass)                         # Enqueues scan lane4 with passenger
                        line4_count += 1                                # Scan lane4 passenger count increased
                        line4_wait.pass_enter_time(total_time_count)    # Sends the enter time to the passenger class
                    else:
                        pass                                            # If no conditions are met, pass


        if line1_time_count >= scan_check_time:                             # Checks it lane1 count time is greater or equal to user input
            if line1.is_empty() != True:                                    # Checks if the lane1 scan is empty
                line1.dequeue()                                             # If not empty, dequeue passenger form the lane1 scan
                line1_wait.pass_exit_time(total_time_count)                 # Sends the exit time to passenger class for lane1 lane wait time
                line1_wait_times += line1_wait.return_wait_time()           # Gets the wait time of passenger in lane1, adds to accumulator
                pass_total_line1 += 1                                       # Adds to lane1 passenger total cleared accumulator
                line1_count -= 1                                            # Reduces the length of passengers in the lane1 by 1
                pass_total += 1                                             # Adds passenger to the total passenger accumulator
            line1_time_count = 0                                            # Resets lane1 time counter

        if line2_time_count >= scan_check_time:                             # Checks it lane2 count time is greater or equal to user input
            if line2.is_empty() != True:                                    # Checks if the lane2 scan is empty
                line2.dequeue()                                             # If not empty, dequeue passenger form the lane2 scan
                line2_wait.pass_exit_time(total_time_count)                 # Sends the exit time to passenger class for lane2 wait time
                line2_wait_times += line2_wait.return_wait_time()           # Gets the wait time of passenger in lane2, adds to accumulator
                pass_total_line2 += 1                                       # Adds to lane2 passenger total cleared accumulator
                line2_count -= 1                                            # Reduces the length of passengers in the lane2 by 1
                pass_total += 1                                             # Adds passenger to the total passenger accumulator
            line2_time_count = 0                                            # Resets lane2 time counter

        if line3_time_count - 1 >= scan_check_time:                         # Checks it lane3 count time is greater or equal to user input
            if line3.is_empty() != True:                                    # Checks if the lane3 scan is empty
                line3.dequeue()                                             # If not empty, dequeue passenger form the lane3 scan
                line3_wait.pass_exit_time(total_time_count)                 # Sends the exit time to passenger class for lane3 lane wait time
                line3_wait_times += line3_wait.return_wait_time()           # Gets the wait time of passenger in lane3, adds to accumulator
                pass_total_line3 += 1                                       # Adds to lane3 passenger total cleared accumulator
                line3_count -= 1                                            # Reduces the length of passengers in the lane3 by 1
                pass_total += 1                                             # Adds passenger to the total passenger accumulator
            line3_time_count = 0                                            # Resets TSA lane3 time counter

        if line4_time_count >= scan_check_time:                             # Checks it lane4 count time is greater or equal to user input
            if line4.is_empty() != True:                                    # Checks if the lane4 scan is empty
                line4.dequeue()                                             # If not empty, dequeue passenger form the lane4 scan
                line4_wait.pass_exit_time(total_time_count)                 # Sends the exit time to passenger class for lane4 lane wait time
                line4_wait_times += line4_wait.return_wait_time()           # Gets the wait time of passenger in lane4, adds to accumulator
                pass_total_line4 += 1                                       # Adds to lane4 passenger total cleared accumulator
                line4_count -= 1                                            # Reduces the length of passengers in the lane4 by 1
                pass_total += 1                                             # Adds passenger to the total passenger accumulator
            line4_time_count = 0                                            # Resets lane4 time counter

        tsa_id_line_count += 1      # Adds one second to the TSA ID lane time count
        reg_id_line_count += 1      # Adds one second to the regular ID lane time count
        tsa_scan_line_count += 1    # Adds one second to the TSA scan lane time count
        line1_time_count += 1       # Adds one second to the line1 scan time count
        line2_time_count += 1       # Add one second to the line2 scan time count
        line3_time_count += 1       # Add one second to the line3 scan time count
        line4_time_count += 1       # Add one second to the line4 scan time count
        total_time_count += 1       # Add one second to the total time count

    total_wait_times = line1_wait_times + line2_wait_times \
                        + line3_wait_times + line4_wait_times + tsa_wait_times  # Add together the wait times in each
                                                                                # lane and assign variable

    print("")
    print("Simulation lenth:", sim_time, "minutes")                # Print the simulation time
    print("Passenger arrival probability:", pass_prob)             # Print the passenger probability
    print("Simulate Precheck:", tsa_check)                         # Print if the TSA check is active

    print("")

    if pass_total == 0:                                             # Check if there were any passengers cleared,
        print("There were no passengers.")                          # if not, print
    else:
        print("Number of passengers Cleared:", pass_total)          # Else, print the cleared total passengers
        average_wait_time = (total_wait_times / pass_total) / 60    # Assign the average total wait times for all lanes
        print("Average wait time:", format\
            (average_wait_time, '.2f'), "minutes")                  # Print the result

    if pass_total_line1 == 0:                                       # Check if there were any passengers cleared,
        print("There were no passengers in lane 1.")                # if not, print
    else:                                                           # Else, print the wait average of cleared passengers in lane1
        line1_average_wait_time = (line1_wait_times / pass_total_line1) / 60
        print("Average lane 1 wait time:",format \
            (line1_average_wait_time, '.2f'),"minutes","(",pass_total_line1,"people",")")

    if pass_total_line2 == 0:                                       # Check if there were any passengers cleared,
        print("There were no passengers in lane 2.")                # if not print
    else:                                                           # Else, print the wait average of cleared passengers in lane2
        line2_average_wait_time = (line2_wait_times / pass_total_line2) / 60
        print("Average lane 2 wait time:", format \
            (line2_average_wait_time, '.2f'), "minutes","(",pass_total_line2,"people",")")

    if pass_total_line3 == 0:                                       # Check if there were any passengers cleared,
        print("There were no passengers in lane 3.")                # if not, print
    else:                                                           # Else, print the wait average of cleared passengers in lane3
        line3_average_wait_time = (line3_wait_times / pass_total_line3) / 60
        print("Average lane 3 wait time:", format \
            (line3_average_wait_time, '.2f'), "minutes","(",pass_total_line3,"people",")")

    if pass_total_line4 == 0:                                       # Check if there were any passengers cleared,
        print("There were no passengers in lane 4.")                # if not, print
    else:                                                           # Else, print the wait average of cleared passengers in lane4
        line4_average_wait_time = (line4_wait_times / pass_total_line4) / 60
        print("Average lane 4 wait time:", format\
            (line4_average_wait_time, '.2f'), "minutes","(",pass_total_line4,"people",")")

    if tsa_check == "Y":                                            # Check if TSA check is active
        if tsa_pass_total == 0:                                     # Check if there were any passengers cleared,
            print("There were no passengers in TSA lane.")          # if not, print
        else:                                                       # Else, print the wait average of cleared passengers in TSA lane
            tsa_average_wait_time = (tsa_wait_times / tsa_pass_total) / 60
            print("Average TSA lane wait time:", format\
                (tsa_average_wait_time, '.2f'), "minutes","(",tsa_pass_total,"people",")")


main()