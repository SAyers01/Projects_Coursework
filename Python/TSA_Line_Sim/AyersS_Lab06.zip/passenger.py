# Seth Ayers
# CSIT 200 - 01
# 10/20/2016
# lab6
# passenger.py


class Passenger:
    """The Passenger class holds the enter times and exit times of the passengers then returns the wait times"""
    def __init__(self):
        """Constructs passengers"""
        self._passenger_enter_time = 0
        self._passenger_exit_time = 0

    def pass_enter_time(self, t):
        """Sets the enter times of the passenger"""
        self._passenger_enter_time = t          # t is the passed time that the passenger enters a lane

    def pass_exit_time(self, e):
        """Sets the exit time of the passenger"""
        self._passenger_exit_time = e           # t is the passed time that the passenger exits a lane

    def return_wait_time(self):
        """Returns the difference of the enter and exit times"""
        return self._passenger_exit_time - self._passenger_enter_time   # exit time is subtracted from enter and returned


