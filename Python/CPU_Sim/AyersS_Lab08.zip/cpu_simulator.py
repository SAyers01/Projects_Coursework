# Seth Ayers
# CSIT - 200 -1
# 10/26/2016
# lab 8
# cpu_simulator.py

import priority_queue                       # Import the priority queue file
import random                               # Import the random module

def start_simulation():
    """Starts the simulation"""
    simulation()

def simulation():
    """Asks the user a series of parameters that are used to simulate how cpu's processes according to priority"""
    pq = priority_queue.HeapPriorityQueue()                     # Make instance of the priority queue class
    slice_num = 1                                               # Counter for the iterations of the loop
    end_process_count = 0                                       # Counter for the total amount of processes finished

    sim_format = input('Enter simulation format, (F)ile or (R)andom: ')                 # User input for file or random
    while sim_format != "F" and sim_format != "R":                                      # Validation loop for above input
        sim_format = input('Enter the correct format, F for file or R for random: ')

    cpu_num = int(input('Enter number of CPUs (Number greater than 0): '))                              # User inputs number of cpu's to be used
    while cpu_num < 1:                                                          # Validation for above input
        cpu_num = int(input('Enter number of CPUs (0>): '))

    if sim_format == "F":                                     # If the user wants to read of a file, call on the
        filename = input('Enter filename: ')  # User inputs file name
        list_of_jobs = read_file(filename)                    # read file function
    else:
        probability = float(input("Enter the probability that a new job is created each time-slice (0-1): "))
        while probability < 0 or probability > 1:                                   # If user decides on a randomly made
            probability = float(input("Enter a correct format! (0 through 1):"))    # list, user inputs the probability of
        length_of_sim = int(input("Please enter the simulation length: "))          # a process being added to the queue
        while length_of_sim < 0:                                                    # and the length of the simulation.
            length_of_sim = int(input("Please enter a positive number."))           # Both inputs are validated
        list_of_jobs = rand_list(length_of_sim)                                     # The random list function is called and returns a list
    cpu_list = compile_cpu_list(cpu_num)                                      # A list of CPU's are created form user input

    for x in range(len(list_of_jobs)):                      # A loop is made for number of jobs in the list of jobs
        if list_of_jobs[x][0] != 'No job':                  # If the index of x does not equal "no job" each index of sub
            process = list_of_jobs[x][0]                    # [x] is given a variable.  These are used to make the value and
            time_slice = list_of_jobs[x][1]                 # and key to adds them to the queue.
            priority = list_of_jobs[x][2]
            value = [process, time_slice]
            pq.add(int(priority),value)

        for x in range(len(cpu_list)):                      # Loop for the each cpu in the cpu list
            if len(cpu_list[x]) == 0:                       # Checks if the length of [x] is zero, meaning its empty
                if sim_format == "F":                       # Checks if user is reading from the file
                    if pq.is_empty() == False:              # Checks if the queue is empty
                        node = pq.remove_min()              # If all above conditions are met, the root of the queue is removed
                        process = node[1][0]                # The process label is assigned a variable
                        time = node[1][1]                   # The slice_time of the process is given a variable
                        cpu_list[x] = [process, int(time)]  # Index [x] is now the combined list of process and time

                if sim_format == "R":                       # Checks if users is accessing the randomized list.
                    if probability > random.uniform(0,1):   # Compares uniform against probability input to check if a
                        if pq.is_empty() == False:          # process is taken from the queue and assigned a cpu.
                            node = pq.remove_min()          # If all above conditions are met, the root of the queue is removed
                            process = node[1][0]            # The process label is assigned a variable
                            time = node[1][1]               # The slice_time of the process is given a variable
                            cpu_list[x] = [process, int(time)]       # Index [x] is now the combined list of process and time

        pre_string = str(slice_num) + ': '                  # Starts building the string that will be used to print the data
                                                            # Concatenates the number_slice counter
        for x in range(len(cpu_list)):                      # Loop for the number of cpu's in the cpu list
            if cpu_list[x] == []:                           # if the cpu has no job, a "-" is printed in it's place
                pre_string += ' -,'                         # Used mainly for ease of user interpretation
            if len(cpu_list[x]) > 0:                        # If the cpu has a current job, the job label (ie 'A') is assigned
                process_str = cpu_list[x][0]                # a variable and concatenates to the pre_string variable
                pre_string += ' ' + str(process_str) + ','

        print(pre_string[:-1])                              # Prints the time_slice number and each process each cpu is
                                                            # processing
        for x in range(len(cpu_list)):                      # Loop for the number of cpu's in the cpu list
            if len(cpu_list[x]) > 0:                        # Check if the cpu of [x] is not empty
                if cpu_list[x][1] == 1:                     # Check if the sub index(time_slice) of [x] is one
                    cpu_list[x] = []                        # If the time slice is one, turn the process to an empty list
                    end_process_count += 1                  # For the finished process, add 1 to the counter
                else:
                    cpu_list[x][1] -= 1                     # If above condition is not met, subtract 1 from the time_slice
                                                            # of the process
        slice_num += 1                                      # Adds 1 to the slice_num counter for the iteration of this main loop
    print("Total number of jobs completed: ",end_process_count)         # Prints the total amount of jobs completed

def read_file(file):
    """When called, reads from the file and inserts the contents to a list, which is returned"""
    list_of_process = []                            # Creates the list for the file lines to append to
    file_name = file                                # Assigns user imputed file to a variable
    file_read = open(file_name, 'r')                # Opens the file
    for line in file_read:                          # Loop to iterate through each line in the file
        line = line.rstrip('\n')                    # Strip the new line
        final = line.split(',')                     # Split the line at each ","
        if final[0] != "No job":                    # Check if the line has "No job"
            file_process = final[0]                 # Assign the indexes of each line variables
            file_slice = final[1]
            file_priority = int(final[2])
            final2 = [file_process,file_slice,file_priority]    # Make a new list with the variables of each line
            list_of_process.append(final2)                      # Append the list with the line content list
        else:
            list_of_process.append(final)                       # Otherwise, add "No Job" to the list
    file_read.close()                                           # CLOSE THE FILE
    return list_of_process                          # Return the list of processes

def rand_list(sim_length):
    """Creates a random list of processes and returns it"""
    rand_list = []                                                  # Build an empty list
    for x in range(sim_length):                                     # Loop in the range of the user imputed simulation run time
        process = x                                                 # Assign x to a variable
        time_slice_rand = random.randint(1,100)                     # Assign a random time slice number, 1-100, to a variable
        rand_priority = random.randint(-20,19)                      # Assign a random priority number, -20 to 19, to a variable
        combined = [process, time_slice_rand, rand_priority]        # Add the variables to a list
        rand_list.append(combined)                                  # Append the variable list to the empty list
    return rand_list                                                # Return the new list of random processes

def compile_cpu_list(num):
    """Builds a CPU list and returns"""
    cpu_list  = []                          # Create an  empty list
    for x in range(num):                    # Loop for the range of the CPUs to be added to list (from passes user input)
        cpu_list.append([])                 # Append the empty list with a sub list for each cpu
    return cpu_list                         # Return the CPU list






