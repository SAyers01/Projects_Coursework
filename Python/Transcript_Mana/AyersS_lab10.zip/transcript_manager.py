# Seth Ayers
# CSIT 200 - 01
# 11/10/2016
# Lab 10
# transcript_manager.py

import linked_stack                                     # Import the linked stack mod
undo = linked_stack.LinkedStack()                       # Instance for the undo linked stack
redo = linked_stack.LinkedStack()                       # Instance for the redo linked stack
dt = {}                                                 # Dictionary created to store transcript courses
grade_points = {"A":4.0,"A-":3.7,"B+":3.3,"B":3.0,"B-":2.7,"C+":2.3,"C":2.0,"C-":1.7,"D+":1.3,"D":1,"D-":0.7,"E":0}   # Grade point conversion list

def main():
    """Simply calls the user interface function"""
    user_interface()

def load_file():
    """Loads a users pre existing transcript file"""
    file_name = input("Please enter a file name: ")            # User inputs file name
    file_read = open(file_name, 'r')                           # File is read, assigned variable
    for line in file_read:                                     # Loop for contents in file, line by line
        line = line.rstrip('\n')                               # Strips the new line
        final = line.split(',')                                # Splits at each comma
        key = final[0]                                         # Key will be the course code as it is a unique variable
        value = final[:]                                       # The Value will consist of everything including course code
        dt[key] = value                                        # Add the key value pair to the dictionary
    file_read.close()
    input("Please press enter to access the main menu.")       # Return to the main menu
    user_interface()

def save_file():
    """Saves all current work performed in a loadable/workable format"""
    file_name = input("Please enter a file name: ")            # User inputs file name
    file_save = open(file_name, "w")                           # File is ready to be writen
    for key in dt:                                             # Loop to iterate through key value pairs
        save_string = dt[key][0]+","+dt[key][1]+","+dt[key][2]+","+dt[key][3]+","+dt[key][4]+","+dt[key][5]     # String with proper formatting for key value pair
        file_save.write(save_string+"\n")                      # Write the string to file, with a new line after every write
    file_save.close()                                          # Close the save file after complete
    input("Please press enter to return to main menu.")
    user_interface()

def user_interface():
    """Control interface for user navigation"""
    print("Student transcript interface.")                     # Simple print statements to assist user with program
    print("Please select from the following menu:")            # interaction
    print("For course lookup, enter 1.")
    print("To update a course, enter 2.")
    print("To find a course, enter 3.")
    print("To show all courses, enter 4.")
    print("To delete a course, enter 5.")
    print("To add a course, enter 6")
    print("To Calculate GPA, enter 7.")
    print("To Calculate field GPA, 8.")
    print("To undo the last Add/Delete, enter 9")
    print("To redo the last undo, enter 10")
    print("To load an existing file, enter 11.")
    print("To save current file, enter 12.")
    selection = int(input(""))                                  # User selects a process and enters the number indicated
    if selection == 1:                                          # All numbers are assigned the corresponding function they
        course_lookup()                                         # represent.  The program then calls the function the user
    elif selection == 2:                                        # wishes to access.
        update_course()
    elif selection == 3:
        find_course()
    elif selection == 4:
        show_all()
    elif selection == 5:
        delete_course()
    elif selection == 6:
        add_course()
    elif selection == 7:
        calculate_gpa()
    elif selection == 8:
        calculate_field_gpa()
    elif selection == 9:
        undo_last()
    elif selection == 10:
        redo_last()
    elif selection == 11:
        load_file()
    elif selection == 12:
        save_file()
    else:
        print("Please enter a number from the list.")               # If the user selects a number not on the list, the
    user_interface()                                                # error message displays and the user interface function
                                                                    # is called again.
def course_lookup():
    """User inputs a course code to view specifics"""
    course_key = input("Please enter a course code you would like to look up: ")   # User enters course code
    if course_key in dt:                                                           # Loop to search for the course in dictionary
        for i in dt[course_key]:                                                   # If the course is in the dictionary, print the course
            print(i)
    else:
        print("That course is not in the transcript.")                             # If course is not found, display error
    input("Please press enter to return to the main menu.")                        # Returns to user interface
    user_interface()

def update_course():
    """Used to update values within a specific course"""
    course_change = input("Enter the course you wish to modify (use course code): ")        # User selects course to modify
    print("To update the course name, select 1.")                                  # Prints the available updates user can perform
    print("To update the credits, select 2.")
    print("To update the letter grade, select 3.")
    print("To update the semester taken, select 4.")
    print("To update the instructor, select 5.")
    user_choice = int(input("Please select a number: "))                      # User selects the modification via number
    if user_choice == 1:
        new_course_name = input("Please enter the new course name.")          # User inputs new course name
        dt[course_change][1] = new_course_name                                # Old course name is replaced with user input
    elif user_choice == 2:
        new_credit = input("Please enter the new credit value.")              # User inputs new credit value
        while int(new_credit) > 4 or int(new_credit) < 0:                               # Input validation check
            new_credit = input("Please enter a value of 1 to 4.")
        dt[course_change][2] = new_credit                                     # Old credit value is replaced with user input
    elif user_choice == 3:
        new_letter_grade = input("Please enter a new letter grade.")          # User inputs new letter grade
        dt[course_change][3] = new_letter_grade                               # Old letter grade is replaced with user input
    elif user_choice == 4:
        new_semester = input("Enter the semester taken.")                     # User inputs new semester
        dt[course_change][4] = new_semester                                   # Old semester is replaced with user input
    elif user_choice == 5:
        new_professor = input("Enter the new professor.")                     # User inputs new instructor
        dt[user_choice][5] = new_professor                                    # Old instructor is replaced with user input
    else:
        input("Please enter a valid number.  Press enter.")                   # If incorrect number is entered, print error
        update_course()                                                       # and call on update course function again
    input("Please press enter to return to the main menu.")                   # When change is complete, return user to main menu
    user_interface()

def add_course():
    """Adds a course to the transcript"""
    course_value = [0,0,0,0,0,0]                                              # Empty list to add new course values
    course_key = input("Please enter a course code: ")                        # User enters a course code which will also
    course_value[0] = course_key                                              # be used as its key
    course_value[1] = input("Please enter the course name: ")                 # User enters the specifics of the course
    course_value[2] = input("Please enter the total credits: ")               # each being assigned to the lists index
    course_value[3] = input("Please enter the grade: ")
    course_value[4] = input("Please enter the semester taken: ")
    course_value[5] = input("Please enter the Professor: ")
    dt[course_key] = course_value                                             # The course list is then added to the dictionaries key as its value
    undo.push([0]+dt[course_key])                                             # The key value is sent to a stack for undo, 0 is added
    input("Please press enter to return to the main menu.")                   # to indicate this course was added
    user_interface()                                                          # Return user to main menu

def delete_course():
    """Deletes a course within the transcript"""
    user_delete = input("Enter the course code of the class you wish to remove: ")  # User enters the course code of the course to be deleted
    if user_delete in dt:                                               # Finds the course within the transcript
        undo.push([1]+dt[user_delete])                                  # Course added to the undo stack, 1 is added to indicate deletion
        del dt[user_delete]                                             # Delete the course from the dictionary
    else:
        print("That course is not in the transcript")                   # If user inputted course is not in the transcript, error message
    input("Please press enter to return to the main menu.")             # User is returned to the main menu
    user_interface()

def find_course():
    """Finds all courses by user inputted parameters"""
    print("To search by course name, select 1.")                       # Prints navigation instructions for user to select
    print("To search by credits, select 2.")
    print("To search by letter grade, select 3.")
    print("To search by semester taken, select 4.")
    print("To search by instructor, select 5.")
    user_choice = int(input("Please select a number: "))                # User selects an option from above
    if user_choice == 1:                                                # Depending on user selection, the program iterates
        user_search = input("Enter a course name: ")                    # the the value indexes to find a match.  Once a
        for i in dt:                                                    # match is found, it prints (Lines 166-190)
            if user_search == dt[i][1]:
                print(dt[i])
    elif user_choice == 2:
        user_search = input("Enter credits: ")
        for i in dt:
            if user_search == dt[i][2]:
                print(dt[i])
    elif user_choice == 3:
        user_search = input("Enter a letter grade: ")
        for i in dt:
            if user_search == dt[i][3]:
                print(dt[i])
    elif user_choice == 4:
        user_search = input("Enter a semester: ")
        for i in dt:
            if user_search == dt[i][4]:
                print(dt[i])
    elif user_choice == 5:
        user_search = input("Enter a professor: ")
        for i in dt:
            if user_search == dt[i][5]:
                print(dt[i])
    else:
        input("Please enter a valid number. Press enter.")          # If an incorrect selection was made, calls the find course function again
        find_course()
    input("Please press enter to return to the main menu.")         # Returns user to main menu
    user_interface()

def calculate_gpa():
    """Calculates the users GPA"""
    course_hours_total = 0                                            # Accumulator for all of students course hours
    course_grade_point_total = 0                                      # Accumulator for students grade points for each course
    for i in dt:                                                      # Loop for iteration through the dictionary
        grade_point = grade_points[dt[i][3]]                          # Assigns the letter grade to a value in grade point dictionary to a variable
        course_grade_point = float(grade_point) * float(dt[i][2])     # Multiplies the converted GPA by the credit hours found in its value
        course_grade_point_total += course_grade_point                # Adds the result to the course gpa total accumulator
        course_hours_total += int(dt[i][2])                           # Adds the credit hours to the course hours accumulator
    gpa = course_grade_point_total / course_hours_total               # Divide the two accumulators and print the result
    print("The GPA is", format(gpa, '.2f'))
    input("Please press enter to return to the main menu.")           # Return user to main menu
    user_interface()

def calculate_field_gpa():
    """Calculates GPA for specific field of study"""
    department = input("PLease enter a department: ")                       # User selects field
    department_grade_point_total = 0                                        # Accumulator for all of students course hours in specific field
    department_hours_total = 0                                              # Accumulator for students grade points for each course
    for i in dt:                                                            # Loop for iteration through the dictionary
        if str(department[:2]) in [i[:2]]:                                      # Checks if the field in dictionary matches with user input
            grade_point = grade_points[dt[i][3]]                                # Assigns the letter grade to a value in grade point dictionary to a variable
            department_grade_point = float(grade_point) * float(dt[i][2])       # Multiplies the converted GPA by the credit hours found in its value
            department_grade_point_total += department_grade_point              # Adds the result to the department gpa total accumulator
            department_hours_total += int(dt[i][2])                             # Adds the credit hours to the department hours accumulator
    gpa = department_grade_point_total / department_hours_total                 # Divide the two accumulators and print the result
    print("The field GPA for", department,"is", format(gpa, '.2f'))
    input("Please press enter to return to the main menu.")                     # Return user to main menu
    user_interface()

def show_all():
    """Shows all the courses in the transcript in table form"""
    print("COURSE CODE", "\t\t","","COURSE NAME","\t","", "CREDITS","\t", "LETTER GRADE","\t\t","","SEMESTER","\t\t","","PROFESSOR") # Print table headers
    for i in dt:                                                                                            # Iterate through the dictionary
        print(i,"\t\t ",dt[i][1],"\t\t",dt[i][2],"\t\t\t", dt[i][3], "  \t\t\t  ",dt[i][4],"\t", dt[i][5])  # Print the values of the keys
    input("Please press enter to return to the main menu.")         # Return the user to the main menu
    user_interface()

def undo_last():
    """Undoes the last add or delete"""
    if (undo.is_empty()) == False:        # Checks if the undo stack is not empty
        course = undo.pop()                 # if stack is not empty, removes the course from the stack
        if course[0] == 1:                  # Checks if course was either added or deleted by checking index 1
            dt[course[1]] = course[1:]      # If deleted, it adds the course back to the transcript
            redo.push(course)               # Add the course to the redo stack
        else:
            redo.push(course)           # If course was added, deletes the course from the transcript
            del dt[course[1]]
    else:
        print("There are no actions to undo/Last action was not undo/redo.") # IF stack was empty, prints error and
        input("Please press enter to return to the main menu.")              # user to the main menu
    user_interface()

def redo_last():
    """Redoes the last action performed by undo"""
    if (redo.is_empty()) == False:        # Checks if the redo stack is not empty
        course = redo.pop()               # If redo stack is not empty, removes the course from the stack
        print(course)
        if course[0] == 1:                # If course was added by the undo (checking index 1), the course is deleted form the transcript
            del dt[course[1]]
        else:
            dt[course[1]] = course[1:]       # If the course was deleted by undo, the course is added to the transcript
    else:
        print("There are no actions to redo/undo.")                 # If stack is empty, return user to the main menu
        input("Please press enter to return to the main menu.")
    user_interface()

if __name__ == "__main__":  main()